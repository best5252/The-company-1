document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('login-form');
  const errorDiv = document.getElementById('login-error');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const u = form.username.value.trim();
    const p = form.password.value.trim();
    // Demo: username: demo, password: stonewall
    if (u === 'demo' && p === 'stonewall') {
      localStorage.setItem('swv_logged_in', 'true');
      localStorage.setItem('swv_user', u);
      window.location.href = 'dashboard.html';
    } else {
      errorDiv.style.display = 'block';
    }
  });
});