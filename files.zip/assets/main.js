// Navigation logic for login/dashboard button visibility
document.addEventListener('DOMContentLoaded', () => {
  const isLoggedIn = localStorage.getItem('swv_logged_in') === 'true';
  const loginLink = document.getElementById('login-link');
  const dashboardLink = document.getElementById('dashboard-link');
  if (isLoggedIn) {
    if (loginLink) loginLink.style.display = 'none';
    if (dashboardLink) dashboardLink.style.display = '';
  } else {
    if (loginLink) loginLink.style.display = '';
    if (dashboardLink) dashboardLink.style.display = 'none';
  }

  // Contact form dummy handler
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      document.getElementById('contact-success').style.display = 'block';
      contactForm.reset();
    });
  }
});