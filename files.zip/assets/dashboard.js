document.addEventListener('DOMContentLoaded', () => {
  // Redirect if not logged in
  if (localStorage.getItem('swv_logged_in') !== 'true') {
    window.location.href = 'login.html';
    return;
  }

  const user = localStorage.getItem('swv_user') || 'demo';
  document.getElementById('user-welcome').textContent = `Welcome, ${user}!`;

  // Dummy bills data
  const bills = [
    { name: "Security Vault Rental", type: "Vault", amount: "$2,000", status: "Active", paid: "Yes", owin: "No" },
    { name: "Surveillance Plan", type: "Monitoring", amount: "$500", status: "Active", paid: "No", owin: "Yes" },
    { name: "Access Control Setup", type: "Install", amount: "$1,200", status: "Completed", paid: "Yes", owin: "No" },
    { name: "Cybersecurity Audit", type: "Audit", amount: "$900", status: "Pending", paid: "No", owin: "No" }
  ];
  const table = document.getElementById('bills-table');
  bills.forEach(bill => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${bill.name}</td>
      <td>${bill.type}</td>
      <td>${bill.amount}</td>
      <td>${bill.status}</td>
      <td>${bill.paid}</td>
      <td>${bill.owin}</td>`;
    table.appendChild(tr);
  });

  // Logout
  document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('swv_logged_in');
    localStorage.removeItem('swv_user');
    window.location.href = 'index.html';
  });
});